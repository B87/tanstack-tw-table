# Data Table Component

A powerful, enterprise-grade data table component built with TanStack React Table. Features advanced server-side operations, comprehensive filtering, view management, URL synchronization, and statistics support.

## 🚀 Key Features

### Core Functionality

* 🔍 **Advanced Server-Side Filtering** - 20+ filter operators with fluent QueryBuilder API
* 📊 **Smart Sorting & Pagination** - Full server-side support with optimized queries
* 📈 **Statistics Integration** - Server-side aggregate statistics with caching
* 👁️ **Column Management** - Show/hide columns with intelligent persistence
* 💾 **View Management** - Save, share, and manage custom table configurations
* 🔗 **URL Synchronization** - Deep linking support for shareable table states

### Developer Experience

* 🔧 **100% Type-Safe** - Comprehensive TypeScript support with strong typing
* ⚡ **Performance Optimized** - Zero infinite loops, enhanced memoization, smart caching
* 🎨 **Design System Ready** - Built with shadcn/ui and Tailwind CSS
* ♿ **Accessibility First** - WCAG compliant with full keyboard navigation
* 🔌 **Framework Agnostic** - Works with Next.js, React Router, or standalone

### Enterprise Ready

* 🏢 **Scalable Architecture** - Handles large datasets with server-side operations
* 🔒 **Secure by Default** - Input validation and XSS protection
* 📱 **Responsive Design** - Mobile-first approach with adaptive layouts

## 📖 Quick Start

For detailed usage examples and comprehensive documentation, see the usage guides:
- [Client-Side Usage Guide](./docs/client-side-usage.md) - Complete guide for client-side filtering and sorting
- [Server-Side Usage Guide](./docs/server-side-usage.md) - Complete guide for server-side operations

### Installation

```bash
npm install @b87/tanstack-tw-table
# or
pnpm add @b87/tanstack-tw-table
```

Import the CSS theme (Tailwind v4 or v3):

```tsx
import "@b87/tanstack-tw-table/theme.css"; // Tailwind v4
// or
import "@b87/tanstack-tw-table/theme-v3.css"; // Tailwind v3
```

### Client-Side Example

```tsx
import { DataTable } from "@b87/tanstack-tw-table";
import { createNextRouter } from "@b87/tanstack-tw-table/routing";
import type { ColumnDef } from "@tanstack/react-table";

const columns: ColumnDef<User>[] = [
  {
    accessorKey: "name",
    header: "Name",
    meta: { searchable: true }, // Automatically searchable
  },
  {
    accessorKey: "status",
    header: "Status",
    meta: {
      filterable: {
        options: [
          { label: "Active", value: "active" },
          { label: "Inactive", value: "inactive" },
        ],
      },
    },
  },
];

export function UsersTable() {
  const router = createNextRouter(); // or createReactRouter()

  return (
    <DataTable
      data={users}
      columns={columns}
      pageCount={1}
      tableId="users-table"
      router={router}
      features={{
        viewManagement: true,
        rowSelection: true,
        urlSync: true, // Enable URL synchronization for deep linking
      }}
      server={{
        mode: "client", // Client-side filtering/sorting
      }}
    />
  );
}
```

### Server-Side Example

```tsx
import { DataTable } from "@b87/tanstack-tw-table";
import { createNextRouter } from "@b87/tanstack-tw-table/routing";
import { DataTableQueryBuilder } from "@b87/tanstack-tw-table";

export function UsersTableServerSide() {
  const router = createNextRouter();
  const [users, setUsers] = useState<User[]>([]);
  const [pageCount, setPageCount] = useState(0);

  // Fetch data with complete table state
  const fetchData = async (state: DataTableState) => {
    const query = DataTableQueryBuilder.create<User>()
      .filter(state.columnFilters)
      .sort(state.sorting)
      .paginate(state.pagination.pageIndex + 1, state.pagination.pageSize)
      .search(state.globalFilter)
      .build();

    const response = await fetch(`/api/users?${query}`);
    const data = await response.json();
    setUsers(data.users);
    setPageCount(Math.ceil(data.total / state.pagination.pageSize));
  };

  const { table } = useDataTable({
    data: users,
    columns,
    pageCount,
    tableId: "users-server",
    router,
    manualPagination: true,
    manualSorting: true,
    manualFiltering: true,
    // Clean state injection pattern - no need for table.getState()
    onSortingChange: async ({ sorting, state, resetPagination }) => {
      await fetchData({
        ...state,
        sorting,
        pagination: resetPagination
          ? { pageIndex: 0, pageSize: state.pagination.pageSize }
          : state.pagination,
      });
    },
    onFilterChange: async ({ columnFilters, globalFilter, state }) => {
      await fetchData({
        ...state,
        columnFilters,
        globalFilter,
        pagination: { pageIndex: 0, pageSize: state.pagination.pageSize },
      });
    },
    onPaginationChange: async ({ pagination, state }) => {
      await fetchData({ ...state, pagination });
    },
  });

  return <DataTableCore table={table} columns={columns} />;
}
```

See the [usage guides](./docs/) for complete examples, advanced configuration, hooks documentation, and more.

## 📚 Documentation

### Usage Guides

Comprehensive usage documentation is available in the following guides:

- **[Client-Side Usage Guide](./docs/client-side-usage.md)** - Complete guide for client-side tables
  - Basic setup and configuration
  - Column metadata and auto-detection
  - URL synchronization and deep linking
  - View management
  - TypeScript patterns

- **[Server-Side Usage Guide](./docs/server-side-usage.md)** - Complete guide for server-side tables
  - State injection pattern (clean API)
  - QueryBuilder for API integration
  - Server-side filtering, sorting, pagination
  - Statistics and aggregations
  - Error handling and loading states

### Additional Resources

* **TypeScript Support** - Full type safety with generic constraints
* **View Management** - Save, load, and manage custom table configurations
* **URL Synchronization** - Deep linking support for shareable table states
* **Router Adapters** - Next.js, React Router, or standalone (client-only)
* **QueryBuilder** - 20+ filter operators for server-side queries
* **Performance** - Zero infinite loops, optimized memoization, smart caching
* **Accessibility** - WCAG compliant with keyboard navigation

## 🚀 Recent Updates (January 2025)

### ✅ Phase 0: API Improvements (Completed)

* **Framework Agnostic** - Removed Next.js dependency, added router abstraction
* **State Injection Pattern** - Clean server-side callbacks with complete table state
* **Column Metadata Auto-Detection** - Define searchable/filterable in column definitions
* **Simplified API** - Grouped props into `features` and `server` objects
* **Zero Infinite Loops** - Complete fix using refs pattern and memoization
* **URL Synchronization** - Deep linking support with debounced updates

### ✅ QueryBuilder System (Completed)

* **Fluent API**: Chain filters, sorting, and pagination
* **20+ Operators**: Comprehensive filtering capabilities (EQUALS, CONTAINS, DATE_BETWEEN, etc.)
* **Type Safety**: Full TypeScript integration
* **90% Less Code**: Eliminated duplication across pages

### ✅ Server-Side Statistics

* **Accurate Counts**: True dataset statistics, not page-only
* **Performance**: 5-minute caching reduces server load
* **Flexible**: Support custom statistics per table
* **Simple API**: Easy integration with existing tables

### ✅ Advanced Date Filtering

* **DataTableDateFilter**: Specialized date picker component with calendar UI
* **Date Operators**: DATE_EQUALS, DATE_BEFORE, DATE_AFTER, DATE_BETWEEN
* **QueryBuilder Integration**: Seamless server-side date query generation
* **Type Safety**: Full TypeScript support with proper date handling

### ✅ Comprehensive Documentation

* **[Client-Side Usage Guide](./docs/client-side-usage.md)** - 850+ lines with complete examples
* **[Server-Side Usage Guide](./docs/server-side-usage.md)** - 1100+ lines with API patterns
* **TypeScript Patterns** - Best practices and real-world examples
* **Troubleshooting** - Common issues and solutions

### 🔄 Roadmap (Next)

* **npm Publication** - Package ready for public release
* **PostgreSQL Views** - Cross-device view synchronization
* **Team Sharing** - Collaborative view management
* **Advanced Analytics** - Usage metrics and optimization insights
* **Export Enhancements** - PDF, Excel, and custom formats

## 🤝 Contributing

### Adding New Filter Operators

```tsx
// 1. Add to FilterOperators enum
export enum FilterOperator {
  // ... existing operators
  CUSTOM_OPERATOR = "custom_op",
}

// 2. Add to QueryBuilder
export class DataTableQueryBuilder<TData> {
  filter(column: keyof TData, operator: FilterOperator, value: any) {
    if (operator === FilterOperator.CUSTOM_OPERATOR) {
      // Handle custom logic
    }
    // ...
  }
}

// 3. Update API route handling
// Handle the new operator in your API routes
```

### TypeScript Best Practices

**❌ Don't use type assertions:**

```tsx
// BAD: Defeats TypeScript's type checking
const searchableColumns = [
  { id: "name" as keyof User, title: "Name" },
  { id: "invalidField" as keyof User, title: "Invalid" }, // No error, but runtime failure
];
```

**✅ Use proper typing:**

```tsx
// GOOD: TypeScript enforces type safety
const searchableColumns: DataTableSearchableColumn<User>[] = [
  { id: "name", title: "Name" }, // ✅ TypeScript ensures 'name' exists on User
  { id: "invalidField", title: "Invalid" }, // ❌ TypeScript error at compile time
];
```

**✅ Use helper utilities for complex configurations:**

```tsx
import { createColumnConfig, StringKeys, NumberKeys } from "@/components/data-table/utils/column-helpers";

// Type-constrained helpers
const stringSearchableColumns = createStringSearchableColumns<User>([
  { id: "name", title: "Name" }, // ✅ Only string properties allowed
  { id: "email", title: "Email" }, // ✅ Only string properties allowed
  // { id: 'age', title: 'Age' },    // ❌ TypeScript error - age is number
]);

// Fluent builder pattern
const config = createColumnConfig<User>()
  .addSearchable("name", "Name")
  .addSearchable("email", "Email")
  .addFilterable({
    id: "status",
    title: "Status",
    type: "string",
    options: statusOptions,
  })
  .build();
```

### Creating Custom Components

```tsx
// Extend existing components with proper typing
export function CustomDataTable<TData>({ customProp, ...props }: DataTableProps<TData, any> & { customProp: string }) {
  return (
    <div className="custom-wrapper">
      <DataTable {...props} />
      <CustomFooter />
    </div>
  );
}

// Type-safe custom hooks
export function useCustomDataTable<TData>(
  data: TData[],
  columns: ColumnDef<TData, any>[],
  options?: {
    searchableColumns?: Array<{ id: keyof TData; title: string }>;
    filterableColumns?: Array<{ id: keyof TData; title: string; options: any[] }>;
  }
) {
  const searchableColumns = options?.searchableColumns ? createSearchableColumns(options.searchableColumns) : [];

  const filterableColumns = options?.filterableColumns ? createFilterableColumns(options.filterableColumns) : [];

  return useDataTable({
    data,
    columns,
    searchableColumns,
    filterableColumns,
    // ... other options
  });
}
```
